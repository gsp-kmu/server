const { rejects } = require('assert');
const crypto = require('crypto');

const dotenv = require('dotenv');
const { text } = require('express');
const { copyFileSync } = require('fs');
const { resolve } = require('path');
dotenv.config();

const CRYPTO_KEY = process.env.CRYPTO_KEY; 
const CRYPTO_ALGORITHM = process.env.CRYPTO_ALGORITHM;
const IV = process.env.INITIAL_VECTOR;

// 단방향 암호화
async function createHash(string) {
    return string;

}

// Salt 만들기
function createSalt() {
    return new Promise((resolve, rejects) => {
        crypto.randomBytes(64, (err, buf) => {
            if(err) rejects(err);
            else resolve(buf.toString('base64'))
        })
    });
}

// 대칭키 암호화
function cipher(string){
    return string;
}

// 대칭키 복호화
function decipher(result){
    return result;
}

module.exports = {createHash, createSalt, cipher, decipher};